<?php

use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('admin/login', 'Dashboardcontroller@login');
Route::get('admin/register', 'Dashboardcontroller@register');

Route::resource('admin/users', 'UserController');

Route::resource('admin/roles', 'RoleController');

Route::resource('admin/permissions', 'PermissionController');

Route::resource('admin/posts', 'PostController');

Route::resource('admin/category', 'Categoriescontroller');

Route::get('admin/dashboard', 'Dashboardcontroller@dashboard');
// Route::get('admin/create_role_permission', function(){
// 	$role = Role::create(['name' => 'Administer']);
// 	$permission = Permission::create(['name' => 'Administer roles & permission']);
// 	auth()->user()->assignRole('Administer');
// 	auth()->user()->givePermissionTo('Administer roles & permission');
// });