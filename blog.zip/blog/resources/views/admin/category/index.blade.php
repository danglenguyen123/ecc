@extends('admin.app')
@section('title', 'Thể loại')
@section('content')
<div class="content">
    <div class="container-fluid">
        <div class="row ">
            <div class="col-md-12">   
            	<a class="btn btn-outline-primary" href="{{route('category.create')}}">Tạo thể loại</a>
            	<hr/>
                <table id="table_id" class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Tiêu đề</th>
                            <th>Phân cấp</th>
                            <th>Trạng thái</th>
                            <th>Người tạo</th>
                            <th>Ngày đăng</th>
                            <th>Chức năng</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($categories as $category)
                        <tr>
                            <td><b>{{ $category->name }}</b></td>
                            <td></td>
                            <td><?php if($category->status == 1) echo 'Hiện'; else echo "Ẩn"; ?></td>
                            <td></td>
                            <td>{{ $category->created_at }}</td>
                            <td></td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>                           
            </div>
        </div>
    </div>
</div>

@endsection