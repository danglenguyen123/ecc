<div class="sidebar">
    <nav class="sidebar-nav">
        <ul class="nav">
            <li class="nav-title">Chức năng chính</li>

            <li class="nav-item">
                <a href="index.html" class="nav-link active">
                    <i class="icon icon-speedometer"></i> Dashboard
                </a>
            </li>

            <li class="nav-title">Phân Quyền</li>

            <li class="nav-item">
                <a href="{{route('roles.index')}}" class="nav-link">
                    <i class="icon icon-puzzle"></i> Vai trò
                </a>
            </li>

            <li class="nav-item">
                <a href="{{ route('permissions.index') }}" class="nav-link">
                    <i class="icon icon-puzzle"></i> Quyền quản lý
                </a>
            </li>

            <li class="nav-title">Người dùng</li>

            <li class="nav-item">
                <a href="{{route('users.index')}}" class="nav-link">
                    <i class="icon icon-puzzle"></i> Quản lý người dùng
                </a>
            </li>

            <li class="nav-title">Quản lý tin tức</li>

            <li class="nav-item">
                <a href="{{route('category.index')}}" class="nav-link">
                    <i class="icon icon-puzzle"></i> Quản trị thể loại
                </a>
            </li>

            <li class="nav-item">
                <a href="{{route('posts.index')}}" class="nav-link">
                    <i class="icon icon-puzzle"></i> Quản trị bài viết
                </a>
            </li> 

            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="icon icon-puzzle"></i> Quản trị bình luận
                </a>
            </li>            

            <li class="nav-title">Bán Hàng</li>

            <li class="nav-item nav-dropdown">
                <a href="#" class="nav-link nav-dropdown-toggle">
                    <i class="icon icon-umbrella"></i> Tất cả chức năng <i class="fa fa-caret-left"></i>
                </a>

                <ul class="nav-dropdown-items">
                    <li class="nav-item">
                        <a href="blank.html" class="nav-link">
                            <i class="icon icon-umbrella"></i> Thể loại sản phẩm
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="login.html" class="nav-link">
                            <i class="icon icon-umbrella"></i> Sản phẩm
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="register.html" class="nav-link">
                            <i class="icon icon-umbrella"></i> Giỏ hàng
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="invoice.html" class="nav-link">
                            <i class="icon icon-umbrella"></i> Phản hồi
                        </a>
                    </li>

                </ul>
            </li>
        </ul>
    </nav>
</div>