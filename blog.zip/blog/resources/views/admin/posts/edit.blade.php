@extends('admin.app')

@section('title', 'Edit Post')

@section('content')
<div class="content">
    <div class="container-fluid">        
        <form method="post" action="{{ route('posts.update', $post->id) }}" enctype="multipart/form-data" style="width: 100%;">
            @csrf
            {{ method_field('PUT') }}
            <div class="row ">
                <div class="col-md-8">                   
                    <div class="form-group">
                        <label for="normal-input" class="form-control-label">Tiêu đề</label>
                        <input type="text" class="form-control" id="title" name="title" value="{{ old('title', $post->title) }}">
                    </div>

                    <div class="form-group">
                        <label for="single-select" style="width: 100%;">Mục cha</label>
                        <select class="multipleSelect" style="width: 100%" multiple name="categories[]">
                            <?php echo $categories_dropdown; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="textarea">Rút gọi</label>
                        <textarea id="textarea" class="form-control" name="excerpt" rows="4">
                            {!! old('excerpt', $post->excerpt) !!}
                        </textarea>
                    </div>

                    <div class="form-group">
                        <label for="textarea">Nội dung</label>
                        <textarea id="textarea" class="form-control" name="body" rows="6">
                            {!! old('body', $post->body) !!}
                        </textarea>
                    </div>  

                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Chỉnh sửa</button>
                    </div>                 
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <div class="toggle-switch" data-ts-color="primary">
                            <label for="ts2" class="ts-label">Trạng thái</label>
    <input id="ts2" type="checkbox" name="is_active[]" @if($post->is_active == 1) checked @endif hidden="hidden">
                            <label for="ts2" class="ts-helper"></label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="image">Hình nổi bật <span class="required">*</span></label>
                        <input type="file" name="image" id="image" class="form-control">
                        <input type="hidden" name="current_image" value="{{$post->image}}">
                        <img class="img-thumbnail mt-3" src="{{asset('images/blog/small/'.$post->image)}}">
                    </div>
                    <div class="form-group">
                        <label for="allow_comments">Cho phép bình luận <span class="required">*</span></label>
                        <select class="form-control" id="allow_comments" name="allow_comments" required>
                            <option value="1" @if(old('allow_comments', '1') == '1') selected @endif>Yes</option>
                            <option value="0" @if(old('allow_comments') == '0') selected @endif>No</option>
                        </select>
                    </div>
                </div>
            </div>
        </form>        
    </div>
</div>               
@endsection