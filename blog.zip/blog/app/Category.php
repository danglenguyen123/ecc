<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
	protected $table = 'category';
    protected $fillable = [
        'name', 'user_id', 'slugs', 'parent_id', 'status'
    ];

    public function posts(){
        return $this->belongsToMany('App\Post');
    }
    public function user(){
        return $this->belongsTo('App\User');
    }
}
