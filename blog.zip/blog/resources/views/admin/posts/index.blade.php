@extends('admin.app')
@section('content')
<div class="content">
    <div class="container-fluid">
        <div class="row ">
            <div class="col-md-12">    
                <a class="btn btn-outline-primary" href="{{route('posts.create')}}">Thêm bài viết</a>
                <hr/>                         
                <table id="table_id" class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Tiêu đề</th>
                            <th>Nội dung</th>
                            <th>Hình</th>
                            <th>Loại tin</th>
                            <th>Trạng thái</th>
                            <th>Comment</th>
                            <th>Ngày</th>
                            <th>Chức năng</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($posts as $post)
                        <tr>
                            <td><b>{{ $post->title }}</b></td>
                            <td>{{ str_limit($post->body, 100) }}</td>
                            <td><img src="{{asset('images/blog/small/'.$post->image)}}" width="75"></td>
                            <td>
                                <?php
                                $category_arr = DB::table('category_post')
                                ->join('posts', 'category_post.post_id' , '=', 'posts.id')
                                ->join('category', 'category_post.category_id', '=', 'category.id')
                                ->where('posts.id', '=', $post->id)
                                ->select('category.name')
                                ->get();
                                ?>
                                @foreach($category_arr as $category)
                                    <p class="btn btn-secondary btn-sm">{{$category->name}}</p>
                                @endforeach
                            </td>
                            <td>
                                <?php
                                if($post->is_active == 1) echo "Hiện"; else echo "Ẩn";
                                ?>
                            </td>
                            <td>
                                <?php
                                if($post->allow_comments == 1) echo "Cho phép"; else echo "Ẩn";
                                ?>
                            </td>
                            <td>{{$post->created_at}}</td>
                            <td>
                                <a class="btn btn-primary" href="">Xem</a>
                                <a class="btn btn-warning" href="">Sửa</a>
                                <a class="btn btn-danger" href="">Xóa</a>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>                           
            </div>
        </div>
    </div>
</div>

@endsection