<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>@yield('title')</title>
    <link rel="stylesheet" href="{{asset('admin/vendor/simple-line-icons/css/simple-line-icons.css')}}">
    <link rel="stylesheet" href="{{asset('admin/vendor/font-awesome/css/fontawesome-all.min.css')}}">
    <link rel="stylesheet" href="{{asset('admin/css/styles.css')}}">
    <link rel="stylesheet" href="{{asset('admin/css/custom.css')}}">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4-4.1.1/dt-1.10.18/datatables.min.css"/>
    <link rel="stylesheet" href="{{asset('select/fastselect.min.css')}}">
    
    <!-- Scripts -->
    <script>
        window.Laravel = {!! json_encode([
            'csrfToken' => csrf_token(),
        ]) !!};
    </script>
</head>
<body class="sidebar-fixed header-fixed">
    <div class="page-wrapper">        
        @include('admin.include.nav')
        <div class="main-container">
            @include('admin.include.sidebar')

            @yield('content')
        </div>
    </div>
    <script src="{{asset('admin/vendor/jquery/jquery.min.js')}}"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/bs4-4.1.1/dt-1.10.18/datatables.min.js"></script>
    <script src="{{asset('select/fastselect.standalone.min.js')}}"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
    <script src="{{asset('admin/vendor/popper.js/popper.min.js')}}"></script>
    <script src="{{asset('admin/vendor/bootstrap/js/bootstrap.min.js')}}"></script>
    <script src="{{asset('admin/vendor/chart.js/chart.min.js')}}"></script>
    <script src="{{asset('admin/js/carbon.js')}}"></script>
    <script src="{{asset('admin/js/demo.js')}}"></script>
    <script type="text/javascript">
    $(document).ready( function () {
        $('#table_id').DataTable();
        $('.multipleSelect').fastselect();
    });
    </script>
    </body>
</html>
