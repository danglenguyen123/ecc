<?php $__env->startSection('title', 'Thể loại'); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row ">
            <div class="col-md-12">   
            	<a class="btn btn-outline-primary" href="<?php echo e(route('category.create')); ?>">Tạo thể loại</a>
            	<hr/>
                <table id="table_id" class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Tiêu đề</th>
                            <th>Phân cấp</th>
                            <th>Trạng thái</th>
                            <th>Người tạo</th>
                            <th>Ngày đăng</th>
                            <th>Chức năng</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><b><?php echo e($category->name); ?></b></td>
                            <td></td>
                            <td><?php if($category->status == 1) echo 'Hiện'; else echo "Ẩn"; ?></td>
                            <td></td>
                            <td><?php echo e($category->created_at); ?></td>
                            <td></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>                           
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>