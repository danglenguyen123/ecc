@extends('admin.app')
@section('title', 'Thêm thể loại')
@section('content')
<div class="content">
    <div class="container-fluid">
        <div class="row ">
            <div class="col-md-6">   
            	<form method="post" action="{{route('category.store')}}">
            		{{ csrf_field() }}
            		<div class="form-group">
                        <label for="normal-input" class="form-control-label">Tiêu đề</label>
                        <input id="normal-input" class="form-control" name="name">
                    </div>

                    <div class="form-group">
                        <label for="single-select">Mục cha</label>
                        <select id="single-select" name="parent_id" class="form-control">
                            <option value="0">Vui lòng chọn</option>
                            @foreach($levels as $level)
                            <option value="{{$level->id}}">{{$level->name}}</option>
                            @endforeach
                        </select>
                    </div>

			        <div class="form-group">
				        <div class="toggle-switch" data-ts-color="primary">
	                        <label for="ts2" class="ts-label">Trạng thái</label>
	                        <input id="ts2" type="checkbox" name="status[]" hidden="hidden">
	                        <label for="ts2" class="ts-helper"></label>
	                    </div>
	                </div>

                    <div class="form-group">
                    	<button type="submit" class="btn btn-primary"> Tạo </button>
                    </div>
            	</form>                                 
            </div>
        </div>
    </div>
</div>

@endsection