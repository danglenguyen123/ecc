<?php $__env->startSection('title', 'Thêm thể loại'); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row ">
            <div class="col-md-6">   
            	<form method="post" action="<?php echo e(route('category.store')); ?>">
            		<?php echo e(csrf_field()); ?>

            		<div class="form-group">
                        <label for="normal-input" class="form-control-label">Tiêu đề</label>
                        <input id="normal-input" class="form-control" name="name">
                    </div>

                    <div class="form-group">
                        <label for="single-select">Mục cha</label>
                        <select id="single-select" name="parent_id" class="form-control">
                            <option value="0">Vui lòng chọn</option>
                            <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($level->id); ?>"><?php echo e($level->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

			        <div class="form-group">
				        <div class="toggle-switch" data-ts-color="primary">
	                        <label for="ts2" class="ts-label">Trạng thái</label>
	                        <input id="ts2" type="checkbox" name="status[]" hidden="hidden">
	                        <label for="ts2" class="ts-helper"></label>
	                    </div>
	                </div>

                    <div class="form-group">
                    	<button type="submit" class="btn btn-primary"> Tạo </button>
                    </div>
            	</form>                                 
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>