<?php
// app/Http/Controllers/PostController.php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Category;
use App\Post;
use Auth;
use Session;
use Image;
use DB;
use Illuminate\Support\Facades\Input;

class PostController extends Controller {

    public function __construct() {
        $this->middleware(['auth', 'clearance'])->except('index', 'show');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function index() {
        $posts = DB::table('posts')->get(); //show only 5 items at a time in descending order
        return view('admin.posts.index', compact('posts'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create() {
        $categories = Category::where(['parent_id'=>0])->get();
        $categories_dropdown = "<option value='' disabled>Vui lòng chọn</option>";
        foreach($categories as $cat){
            $categories_dropdown .= "<option value='".$cat->id."'>".$cat->name."</option>";
            $sub_categories = Category::where(['parent_id'=>$cat->id])->get();
            foreach($sub_categories as $sub_cat){
                $categories_dropdown .= "<option value='".$sub_cat->id."'>&nbsp;--&nbsp;".$sub_cat->name."</option>";
            }
        }
        return view('admin.posts.create')->with(compact('categories_dropdown'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request) { 
        if($request->isMethod('post')){
            $data = $request->all();

            $categoryArr = array();
            foreach ($request->categories as $category) {
                if(is_numeric($category)){
                    //Store in array
                    $categoryArr[] = $category;                    
                }
            }

            $post = new Post;

            $post->title = $data['title'];
            $post->slug = str_slug($data['title'], '-');
            if(!empty($data['excerpt'])){
                $post->excerpt = $data['excerpt'];
            }else{
                $post->excerpt = '';
            }
            $post->body = $data['body'];
            $post->user_id = Auth::user()->id;
            $status = Input::get('is_active');
            if($status == null){
                $post->is_active = 0;
            }else{
                $post->is_active = 1;
            }
            // Upload Image
            if($request->hasFile('image')){
                $image_tmp = Input::file('image');
                if($image_tmp->isValid()){
                    $extension = $image_tmp->getClientOriginalExtension();
                    $filename = rand(111,99999).'.'.$extension;
                    $large_image_path = 'images/blog/large/'.$filename;
                    $medium_image_path = 'images/blog/medium/'.$filename;
                    $small_image_path = 'images/blog/small/'.$filename;
                    // Resize Images
                    Image::make($image_tmp)->save($large_image_path);
                    Image::make($image_tmp)->resize(600,600)->save($medium_image_path);
                    Image::make($image_tmp)->resize(300,300)->save($small_image_path);
                    // Store image name in products table
                    $post->image = $filename;
                }
            }
            $post->allow_comments = $data['allow_comments'];
            $post->save();
            $post->categories()->sync($categoryArr);
            
        }       

    //Display a successful message upon save
        return redirect('admin/posts')->with('flash_message', 'Thêm thành công');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id) {
        $post = Post::findOrFail($id); //Find post of id = $id

        return view ('admin.posts.show', compact('post'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id) {
        $post = Post::findOrFail($id);
        $rela_menu = DB::table('category_post')->where('post_id',$id)->get();

        $categories = Category::where(['parent_id'=>0])->get();
        $categories_dropdown = "<option value='' disabled>Vui lòng chọn</option>";
        foreach($categories as $cat){ 
            $categories_dropdown .= "<option value='".$cat->id."'>".$cat->name."</option>";
            $sub_categories = Category::where(['parent_id'=>$cat->id])->get();
            foreach($sub_categories as $sub_cat){
                if(isset($rela_menu)){
                $categories_dropdown .= "<option value='".$sub_cat->id."' checked>&nbsp;--&nbsp;".$sub_cat->name."</option>";
                }
            }
        }
        return view('admin.posts.edit', compact('post','categories_dropdown'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id) {
            $data = $request->all();
            $post = Post::findOrFail($id);

            $post->title = $data['title'];
            $post->slug = str_slug($data['title'], '-');
            if(!empty($data['excerpt'])){
                $post->excerpt = $data['excerpt'];
            }else{
                $post->excerpt = '';
            }
            $post->body = $data['body'];
            $post->user_id = Auth::user()->id;
            $status = Input::get('is_active');
            if($status == null){
                $post->is_active = 0;
            }else{
                $post->is_active = 1;
            }
            
            $post->allow_comments = $data['allow_comments'];
            $post->save();
            return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id) {
        $post = Post::findOrFail($id);
        $post->delete();

        return redirect()->route('admin.posts.index')
            ->with('flash_message',
             'Article successfully deleted');

    }
}