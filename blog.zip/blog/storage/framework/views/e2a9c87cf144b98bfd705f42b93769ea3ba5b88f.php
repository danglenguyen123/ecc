<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row ">
            <div class="col-md-12">    
                <a class="btn btn-outline-primary" href="<?php echo e(route('posts.create')); ?>">Thêm bài viết</a>
                <hr/>                         
                <table id="table_id" class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Tiêu đề</th>
                            <th>Nội dung</th>
                            <th>Hình</th>
                            <th>Loại tin</th>
                            <th>Trạng thái</th>
                            <th>Comment</th>
                            <th>Ngày</th>
                            <th>Chức năng</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><b><?php echo e($post->title); ?></b></td>
                            <td><?php echo e(str_limit($post->body, 100)); ?></td>
                            <td><img src="<?php echo e(asset('images/blog/small/'.$post->image)); ?>" width="75"></td>
                            <td>
                                <?php
                                $category_arr = DB::table('category_post')
                                ->join('posts', 'category_post.post_id' , '=', 'posts.id')
                                ->join('category', 'category_post.category_id', '=', 'category.id')
                                ->where('posts.id', '=', $post->id)
                                ->select('category.name')
                                ->get();
                                ?>
                                <?php $__currentLoopData = $category_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p class="btn btn-secondary btn-sm"><?php echo e($category->name); ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                <?php
                                if($post->is_active == 1) echo "Hiện"; else echo "Ẩn";
                                ?>
                            </td>
                            <td>
                                <?php
                                if($post->allow_comments == 1) echo "Cho phép"; else echo "Ẩn";
                                ?>
                            </td>
                            <td><?php echo e($post->created_at); ?></td>
                            <td>
                                <a class="btn btn-primary" href="">Xem</a>
                                <a class="btn btn-warning" href="">Sửa</a>
                                <a class="btn btn-danger" href="">Xóa</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>                           
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>