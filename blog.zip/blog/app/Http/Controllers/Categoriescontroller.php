<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;
use Auth;
use Session;
use Illuminate\Support\Facades\Input;

class Categoriescontroller extends Controller
{
	public function __construct(){
		$this->middleware(['auth', 'clearance']);
	}
    public function index(){
    	$categories = Category::all();
    	return view('admin.category.index', compact('categories'));
    }
    public function create(){
    	$levels = Category::where(['parent_id'=>0])->get();
    	return view('admin.category.create', compact('levels'));
    }
    public function store(Request $request){
    	if($request->isMethod('post')){
    		$data = $request->all();
    		$category = new Category;
    		$category->name = $data['name'];
    		$category->slugs = str_slug($data['name'], '-');
    		$category->parent_id = $data['parent_id'];
    		$status = Input::get('status');
    		$category->user_id = Auth::user()->id;
    		if($status == null){
    			$category->status = 0;
    		}else{
    			$category->status = 1;
    		}

    		$category->save();
    	}
    	
    	// Back to index with success
    	return redirect('admin/category')->with('custom_success', 'Thêm thể loại');
    }
    public function edit($id){
    	return view('admin.category.edit');
    }
}
