# Carbon - Bootstrap 4 Admin Template
Carbon is a free admin template based on Bootstrap 4. More updates are coming!

![showcase](https://user-images.githubusercontent.com/2684154/34468329-6803714c-ef17-11e7-81a9-82c7eb8df309.png)

## Demo
Demo is available at [Carbon](http://carbon.smartisan.io)

## Documentation
Visit [repository wiki](https://github.com/mohd-isa/carbon/wiki/1.-Installation) for the documentation.

## Bugs and Features
If you have any bug or wish to request a feature, please open an [issue](https://github.com/mohd-isa/carbon/issues)

## Changelog
Please see [CHANGELOG](https://github.com/mohd-isa/carbon/blob/master/CHANGELOG.md) for more information what has changed recently.

## Credits
* [Mohammed Isa](https://github.com/mohd-isa)
* [All Contributors](https://github.com/mohd-isa/carbon/graphs/contributors)

## License
The [MIT License (MIT)](https://github.com/mohd-isa/carbon/blob/master/LICENSE). Please see License File for more information.
