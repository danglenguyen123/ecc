<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Carbon - Admin Template</title>
    <link rel="stylesheet" href="<?php echo e(asset('admin/vendor/simple-line-icons/css/simple-line-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/vendor/font-awesome/css/fontawesome-all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/styles.css')); ?>">
</head>
<body>
<div class="page-wrapper flex-row align-items-center">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <div class="card p-4">
                    <div class="card-header text-center text-uppercase h4 font-weight-light">
                        Register
                    </div>
                    <form method="POST" action="<?php echo e(route('register')); ?>"><?php echo csrf_field(); ?>
	                    <div class="card-body py-5">
	                        <div class="form-group">
	                            <label class="form-control-label">Name</label>
	                            <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
	                            <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
	                        </div>

	                        <div class="form-group">
	                            <label class="form-control-label">Email</label>
	                            <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>
	                            
	                            <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
	                        </div>

	                        <div class="form-group">
	                            <label class="form-control-label">Password</label>
	                            <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>
	                            <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
	                        </div>

	                        <div class="form-group">
	                            <label class="form-control-label">Confirm Password</label>
	                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
	                        </div>
	                    </div>

	                    <div class="card-footer">
	                        <button type="submit" class="btn btn-success btn-block">Create Account</button>
	                    </div>
	                </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo e(asset('admin/vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/vendor/popper.js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/vendor/chart.js/chart.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/carbon.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/demo.js')); ?>"></script>
</body>
</html>
