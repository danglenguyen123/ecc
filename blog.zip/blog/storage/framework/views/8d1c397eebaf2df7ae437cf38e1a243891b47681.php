<?php $__env->startSection('title', '| Edit Permission'); ?>

<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="container-fluid">
        <div class="row ">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h1><i class='fa fa-key'></i> Edit <?php echo e($permission->name); ?></h1>
                    </div>

                    <div class="card-body">
                        <?php echo e(Form::model($permission, array('route' => array('permissions.update', $permission->id), 'method' => 'PUT'))); ?>


                        <div class="form-group">
                            <?php echo e(Form::label('name', 'Permission Name')); ?>

                            <?php echo e(Form::text('name', null, array('class' => 'form-control'))); ?>

                        </div>
                        <br>
                        <?php echo e(Form::submit('Edit', array('class' => 'btn btn-primary'))); ?>


                        <?php echo e(Form::close()); ?>


                    </div>
                </div>
            </div>
        </div>
    </div>
</div>                    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>